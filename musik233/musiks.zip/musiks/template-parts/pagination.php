<?php

the_posts_pagination( 
	array(
	    'mid_size' => 2,
	    'prev_text' => '<i class="fa fa-chevron-left"></i>',
	    'next_text' => '<i class="fa fa-chevron-right"></i>',
	    'screen_reader_text' => '&nbsp;'
	)
);
